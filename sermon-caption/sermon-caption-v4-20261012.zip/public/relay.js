// 설교 자막 v3 — 공용 연결 모듈
// - 데이터 저장/전달: Firebase 실시간 DB (실제 예배) 또는 로컬(같은 브라우저 탭끼리, 시험용)
// - 통역사 목소리 중계: WebRTC (통역사 브라우저 → 성도 휴대폰 각각 직접 연결, 신호는 위 저장소로 주고받음)
//
// 경로는 모두 rooms/{방 이름}/ 아래 상대 경로입니다.
//   public/ko/{문장번호}   한국어 자막 (휴대폰·통역사가 읽음)
//   public/live           말하는 중인 한국어 (미리 보기)
//   public/tr/{키}        통역사가 확인해서 보낸 글 (휴대폰이 읽음)
//   public/status         { voice, voiceSession, lang }
//   staff/mt/{문장번호}    기계 번역 (통역사 참고용 — 성도는 읽을 수 없음)
//   signal/{성도 uid}      목소리 연결용 신호 (offer/answer/후보 주소)

const FB = 'https://www.gstatic.com/firebasejs/10.12.2/';

export function getConfig() {
  const cfg = Object.assign({ backend: 'local', room: 'main', firebase: null, staffUid: '', iceServers: [] }, window.SC_CONFIG || {});
  const q = new URLSearchParams(location.search);
  if (q.get('room')) cfg.room = q.get('room').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40) || cfg.room;
  if (q.get('local') === '1') cfg.backend = 'local';
  if (cfg.backend === 'firebase' && (!cfg.firebase || !cfg.firebase.apiKey || /여기에/.test(cfg.firebase.apiKey))) {
    cfg.backend = 'local';
    cfg.configMissing = true;
  }
  if (!cfg.iceServers || !cfg.iceServers.length) cfg.iceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
  return cfg;
}

// 시간 순서대로 정렬되는 키 (Firebase push 키와 같은 성질)
export function newKey() {
  return Date.now().toString(36).padStart(9, '0') + Math.random().toString(36).slice(2, 8);
}
export const segKey = (id) => String(id).padStart(6, '0');

function getPath(obj, path) {
  if (!path) return obj;
  return path.split('/').reduce((o, k) => (o && typeof o === 'object' ? o[k] : undefined), obj);
}
function clean(v) { return v === undefined ? null : JSON.parse(JSON.stringify(v)); }

// ───────────────────────── 로컬(시험용) 저장소 ─────────────────────────
function createLocalRelay(cfg, role) {
  const KEY = 'sc.localdb.' + cfg.room;
  const bc = 'BroadcastChannel' in self ? new BroadcastChannel('sc-local-' + cfg.room) : null;
  let uid = sessionStorage.getItem('sc.local.uid');
  if (!uid) { uid = 'local-' + Math.random().toString(36).slice(2, 10); sessionStorage.setItem('sc.local.uid', uid); }
  const subs = new Set();

  const read = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
  function write(mutate) {
    const db = read();
    mutate(db);
    localStorage.setItem(KEY, JSON.stringify(db));
    notify();
    if (bc) bc.postMessage(1);
  }
  function setIn(db, path, value) {
    const parts = path.split('/');
    let o = db;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!o[parts[i]] || typeof o[parts[i]] !== 'object') o[parts[i]] = {};
      o = o[parts[i]];
    }
    const last = parts[parts.length - 1];
    if (value === null || value === undefined) delete o[last]; else o[last] = value;
  }
  const sortKeys = (keys) => keys.sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));

  function notify() {
    const db = read();
    subs.forEach((s) => s.check(db));
  }
  if (bc) bc.onmessage = () => notify();
  window.addEventListener('storage', (e) => { if (e.key === KEY) notify(); });

  const relay = {
    mode: 'local', room: cfg.room, uid, isStaff: role === 'staff',
    async set(path, v) { write((db) => setIn(db, path, clean(v))); },
    async update(path, obj) { write((db) => Object.entries(obj).forEach(([k, v]) => setIn(db, path + '/' + k, clean(v)))); },
    async push(path, v) { const k = newKey(); write((db) => setIn(db, path + '/' + k, clean(v))); return k; },
    async remove(path) { write((db) => setIn(db, path, null)); },
    on(path, cb) {
      let last;
      const s = { check(db) { const v = getPath(db, path); const j = JSON.stringify(v === undefined ? null : v); if (j !== last) { last = j; cb(v === undefined ? null : JSON.parse(j)); } } };
      subs.add(s); s.check(read());
      return () => subs.delete(s);
    },
    onAdded(path, cb) {
      const seen = new Set();
      const s = { check(db) {
        const o = getPath(db, path) || {};
        const keys = sortKeys(Object.keys(o));
        seen.forEach((k) => { if (!(k in o)) seen.delete(k); });
        keys.forEach((k) => { if (!seen.has(k)) { seen.add(k); cb(k, o[k]); } });
      } };
      subs.add(s); s.check(read());
      return () => subs.delete(s);
    },
    onRemoved(path, cb) {
      let prev = null;
      const s = { check(db) {
        const keys = Object.keys(getPath(db, path) || {});
        if (prev) prev.forEach((k) => { if (!keys.includes(k)) cb(k); });
        prev = keys;
      } };
      subs.add(s); s.check(read());
      return () => subs.delete(s);
    },
    onDisconnectRemove(path) { window.addEventListener('pagehide', () => relay.remove(path)); },
    onConnection(cb) { cb(true); return () => {}; }
  };
  return relay;
}

// ───────────────────────── Firebase 저장소 ─────────────────────────
async function createFirebaseRelay(cfg, role) {
  const [{ initializeApp }, A, D] = await Promise.all([
    import(FB + 'firebase-app.js'), import(FB + 'firebase-auth.js'), import(FB + 'firebase-database.js')
  ]);
  const app = initializeApp(cfg.firebase);
  const auth = A.getAuth(app);
  const db = D.getDatabase(app);
  const base = 'rooms/' + cfg.room + '/';
  const r = (p) => D.ref(db, base + p);

  // 로그인 상태가 정해질 때까지 기다림
  let user = await new Promise((res) => { const u = A.onAuthStateChanged(auth, (x) => { u(); res(x); }); });
  if (role === 'staff') {
    if (!user || user.isAnonymous || (cfg.staffUid && user.uid !== cfg.staffUid)) {
      user = await staffLogin(async (email, pw) => (await A.signInWithEmailAndPassword(auth, email, pw)).user, cfg);
    }
  } else if (!user) {
    user = (await A.signInAnonymously(auth)).user;
  }

  return {
    mode: 'firebase', room: cfg.room, uid: user.uid, isStaff: role === 'staff',
    set: (p, v) => D.set(r(p), clean(v)),
    update: (p, obj) => D.update(r(p), clean(obj)),
    async push(p, v) { const k = newKey(); await D.set(r(p + '/' + k), clean(v)); return k; },
    remove: (p) => D.remove(r(p)),
    on(p, cb) { return D.onValue(r(p), (s) => cb(s.val())); },
    onAdded(p, cb) { return D.onChildAdded(r(p), (s) => cb(s.key, s.val())); },
    onRemoved(p, cb) { return D.onChildRemoved(r(p), (s) => cb(s.key)); },
    onDisconnectRemove(p) { D.onDisconnect(r(p)).remove(); },
    onConnection(cb) { return D.onValue(D.ref(db, '.info/connected'), (s) => cb(!!s.val())); },
    signOut: () => A.signOut(auth)
  };
}

// 운영자·통역사 로그인 창 (Firebase 콘솔에서 만든 이메일 계정)
function staffLogin(signIn, cfg) {
  return new Promise((resolve) => {
    const box = document.createElement('div');
    box.style.cssText = 'position:fixed;inset:0;z-index:999;background:rgba(0,0,0,.75);display:grid;place-items:center;padding:16px;font-family:inherit';
    const form = document.createElement('form');
    form.style.cssText = 'background:#1e222b;color:#f2f3f5;border:1px solid #2a2f3a;border-radius:12px;padding:20px;width:min(360px,100%);display:grid;gap:10px';
    const h = document.createElement('h2'); h.textContent = '운영자·통역사 로그인'; h.style.margin = '0';
    const p = document.createElement('p'); p.style.cssText = 'margin:0;font-size:13px;color:#8b93a3';
    p.textContent = 'Firebase 콘솔에서 만든 교회 운영용 계정으로 한 번만 로그인하면 이 컴퓨터에서는 기억됩니다. (방: ' + cfg.room + ')';
    const mk = (type, ph) => { const i = document.createElement('input'); i.type = type; i.placeholder = ph; i.required = true; i.style.cssText = 'padding:10px;border-radius:8px;border:1px solid #2a2f3a;background:#171a21;color:#f2f3f5;font:inherit'; return i; };
    const email = mk('email', '이메일'); email.autocomplete = 'username';
    const pw = mk('password', '비밀번호'); pw.autocomplete = 'current-password';
    const msg = document.createElement('p'); msg.style.cssText = 'margin:0;font-size:13px;color:#ef5b5b;min-height:1em';
    const btn = document.createElement('button'); btn.type = 'submit'; btn.textContent = '로그인';
    btn.style.cssText = 'padding:10px;border-radius:8px;border:0;background:#3fb68b;color:#0b1a14;font-weight:700;font:inherit;cursor:pointer';
    form.append(h, p, email, pw, msg, btn);
    box.append(form);
    document.body.append(box);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      btn.disabled = true; msg.textContent = '';
      try {
        const u = await signIn(email.value.trim(), pw.value);
        if (cfg.staffUid && u.uid !== cfg.staffUid) throw new Error('이 계정은 운영 계정으로 등록되어 있지 않습니다 (config.js의 staffUid 확인).');
        box.remove();
        resolve(u);
      } catch (err) {
        msg.textContent = /invalid|wrong|credential|user-not-found/i.test(String(err && err.code || err)) ? '이메일 또는 비밀번호가 맞지 않습니다.' : String(err.message || err);
        btn.disabled = false;
      }
    });
  });
}

export async function createRelay(role) {
  const cfg = getConfig();
  const relay = cfg.backend === 'firebase' ? await createFirebaseRelay(cfg, role) : createLocalRelay(cfg, role);
  relay.cfg = cfg;
  return relay;
}

export function listenUrl(cfg) {
  const u = new URL('listen.html', location.href);
  u.search = '';
  u.hash = '';
  if (cfg.room !== 'main') u.searchParams.set('room', cfg.room);
  if (cfg.backend === 'local') u.searchParams.set('local', '1');
  return u.href;
}

// ───────────────────────── 목소리 중계 (WebRTC) ─────────────────────────

// 통역사 쪽: 마이크 소리를 접속한 휴대폰마다 하나씩 연결해 보냄
export function startBroadcast(relay, stream, onChange) {
  const peers = new Map(); // uid → { pc, join, unsubs, state }
  const report = () => onChange && onChange([...peers.entries()].map(([uid, p]) => ({ uid, state: p.state })));

  function close(uid) {
    const p = peers.get(uid);
    if (!p) return;
    p.unsubs.forEach((u) => u());
    try { p.pc.close(); } catch (e) { /* 무시 */ }
    peers.delete(uid);
    report();
  }

  async function connect(uid, join) {
    const pc = new RTCPeerConnection({ iceServers: relay.cfg.iceServers });
    const p = { pc, join, unsubs: [], state: '연결 중', queue: [] };
    peers.set(uid, p);
    report();
    stream.getAudioTracks().forEach((t) => pc.addTrack(t, stream));
    pc.onicecandidate = (e) => { if (e.candidate) relay.push('signal/' + uid + '/candB', Object.assign(e.candidate.toJSON(), { join })); };
    pc.onconnectionstatechange = () => {
      p.state = { connected: '듣는 중', connecting: '연결 중', new: '연결 중', disconnected: '끊김(재연결 대기)', failed: '실패', closed: '닫힘' }[pc.connectionState] || pc.connectionState;
      report();
    };
    const offer = await pc.createOffer({ offerToReceiveAudio: false });
    await pc.setLocalDescription(offer);
    await relay.set('signal/' + uid + '/offer', { type: offer.type, sdp: offer.sdp, join });
    p.unsubs.push(relay.on('signal/' + uid + '/answer', async (a) => {
      if (!a || a.join !== join || pc.currentRemoteDescription) return;
      try {
        await pc.setRemoteDescription({ type: a.type, sdp: a.sdp });
        p.queue.splice(0).forEach((c) => pc.addIceCandidate(c).catch(() => {}));
      } catch (e) { console.warn('answer 처리 실패', e); }
    }));
    p.unsubs.push(relay.onAdded('signal/' + uid + '/candL', (k, c) => {
      if (!c || c.join !== join) return;
      if (pc.remoteDescription) pc.addIceCandidate(c).catch(() => {}); else p.queue.push(c);
    }));
  }

  const unsub = relay.on('signal', (all) => {
    all = all || {};
    Object.entries(all).forEach(([uid, s]) => {
      if (!s || !s.join) return;
      const p = peers.get(uid);
      if (!p || p.join !== s.join) { close(uid); connect(uid, s.join).catch((e) => console.warn('연결 실패', uid, e)); }
    });
    [...peers.keys()].forEach((uid) => { if (!all[uid]) close(uid); });
  });

  return {
    stop() { unsub(); [...peers.keys()].forEach(close); },
    get count() { return [...peers.values()].filter((p) => p.state === '듣는 중').length; }
  };
}

// 성도 쪽: 통역사 목소리를 받아 audio 요소로 재생
// 연결 한 번(join)마다 상태를 따로 두어, 늦게 도착한 이전 연결의 이벤트·타이머가 새 연결을 건드리지 않게 함
export function startListening(relay, audio, onState) {
  const me = 'signal/' + relay.uid;
  let stopped = false;
  let cur = null; // 지금 연결 { jid, pc, unsubs, timers }

  function end(sess) {
    if (!sess) return;
    sess.dead = true;
    sess.unsubs.forEach((u) => u());
    sess.timers.forEach(clearTimeout);
    if (sess.pc) { try { sess.pc.close(); } catch (e) { /* 무시 */ } }
  }

  async function join() {
    end(cur);
    if (stopped) return;
    const sess = { jid: newKey(), pc: null, unsubs: [], timers: [], queue: [], dead: false };
    cur = sess;
    const live = () => !sess.dead && cur === sess;
    const retry = (ms, why) => {
      onState(why);
      sess.timers.push(setTimeout(() => { if (live() && (!sess.pc || sess.pc.connectionState !== 'connected')) join(); }, ms));
    };
    onState('연결 중…');
    await relay.set(me, { join: sess.jid });
    if (!live()) return;
    relay.onDisconnectRemove(me);
    // 통역사 쪽이 15초 안에 응답하지 않으면 다시 신청
    retry(15000, '연결 중…');
    sess.unsubs.push(relay.on(me + '/offer', async (o) => {
      if (!live() || !o || o.join !== sess.jid || sess.pc) return;
      const pc = new RTCPeerConnection({ iceServers: relay.cfg.iceServers });
      sess.pc = pc;
      pc.ontrack = (e) => {
        if (!live()) return;
        audio.srcObject = e.streams[0] || new MediaStream([e.track]);
        audio.play().then(() => live() && onState('듣는 중')).catch(() => onState('소리 막힘: 화면을 한 번 눌러 주세요'));
      };
      pc.onicecandidate = (e) => { if (live() && e.candidate) relay.push(me + '/candL', Object.assign(e.candidate.toJSON(), { join: sess.jid })); };
      pc.onconnectionstatechange = () => {
        if (!live()) return;
        const st = pc.connectionState;
        if (st === 'connected') onState('듣는 중');
        else if (st === 'failed') retry(3000, '연결 실패: 다시 시도합니다');
        else if (st === 'disconnected') retry(6000, '끊김: 다시 연결 대기');
      };
      try {
        await pc.setRemoteDescription({ type: o.type, sdp: o.sdp });
        sess.queue.splice(0).forEach((c) => pc.addIceCandidate(c).catch(() => {}));
        const ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        if (live()) await relay.set(me + '/answer', { type: ans.type, sdp: ans.sdp, join: sess.jid });
      } catch (e) {
        if (live()) retry(3000, '연결 오류: 다시 시도합니다');
      }
    }));
    sess.unsubs.push(relay.onAdded(me + '/candB', (k, c) => {
      if (!live() || !c || c.join !== sess.jid) return;
      if (sess.pc && sess.pc.remoteDescription) sess.pc.addIceCandidate(c).catch(() => {}); else sess.queue.push(c);
    }));
  }

  join().catch((e) => onState('연결 오류: ' + (e.message || e)));
  return {
    rejoin() { if (!stopped) join().catch((e) => onState('연결 오류: ' + (e.message || e))); },
    // 통역사가 방송을 멈추면 연결을 닫고 다음 방송 시작(rejoin)을 기다림
    pause() { end(cur); cur = null; },
    stop() { stopped = true; end(cur); cur = null; relay.remove(me); audio.srcObject = null; onState('꺼짐'); }
  };
}
