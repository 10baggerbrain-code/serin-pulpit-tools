// 설교 자막 v3 설정 — README.md의 "Firebase 설정" 순서대로 채우세요.
//
// firebase 값은 Firebase 콘솔 → 프로젝트 설정 → 내 앱(웹)에서 복사합니다.
// 이 값은 원래 공개되는 값이라 비밀번호가 아닙니다. 보호는 database.rules.json(쓰기 권한)이 맡습니다.
// 단, 운영 계정의 이메일·비밀번호는 여기에 절대 적지 마세요.
window.SC_CONFIG = {
  // 'firebase' = 실제 예배용, 'local' = 같은 컴퓨터 브라우저 탭끼리만 (시험용)
  backend: 'local',

  // 방 이름 (영문·숫자). 여러 예배를 따로 돌릴 때 바꿉니다. 주소 뒤 ?room=이름 으로도 바꿀 수 있습니다.
  room: 'main',

  firebase: {
    apiKey: '여기에 붙여넣기',
    authDomain: '',
    databaseURL: '',
    projectId: '',
    appId: ''
  },

  // 운영 계정의 UID (Firebase 콘솔 → Authentication → 사용자 목록에서 복사).
  // database.rules.json의 STAFF_UID 자리에도 같은 값을 넣어야 합니다.
  staffUid: '',

  // 비워 두면 구글 공개 STUN 서버를 씁니다. (TURN 서버가 없어서 일부 휴대폰 데이터망에서는 목소리 연결이 안 될 수 있음)
  iceServers: []
};
